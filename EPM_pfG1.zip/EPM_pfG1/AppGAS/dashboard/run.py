import dash
from dash import dcc, html, Input, Output

app = dash.Dash(__name__, title="EPM Demo")

app.layout = html.Div([
    html.H1("EPM Demo", style={'textAlign': 'center'}),
])


if __name__ == '__main__':
    print("Dashboard en http://127.0.0.1:8050")
    app.run(debug=True, port=8050)