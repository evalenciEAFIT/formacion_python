import pandas as pd

#conetarme a csv
def cargarCSV(fuenteDatos):
    df = pd.read_csv(fuenteDatos)
    return df

