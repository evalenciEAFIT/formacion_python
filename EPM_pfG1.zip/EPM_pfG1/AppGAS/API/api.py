from flask import Flask, request, jsonify, send_file
import pandas as pd

#import sys
#sys.path.append("..")
#import db.cargarDatos as datos
#from ..db.cargarDatos import *
from cargarDatos import *


app = Flask(__name__, static_folder='static')


@app.route("/leerdatos", methods=['GET'])
def cargarDatos():
    #data = datos.cargarCSV()
    fuenteDatos = "datos1.csv"
    print(fuenteDatos)
    data = pd.read_csv("datos1.csv")
    return ("Hoa")

@app.route('/')
def Saludo():
    return ("""<H1>Hola mundo.</H1>
            <br>
            Edison Valencia""")

if __name__ == '__main__':
    print("Dashboard en http://127.0.0.1:8001")
    app.run(debug=True, port=8001)