
def saludo1():
    print ("Hola mundo cruel")

def saludo2():
    print ("Hello cruel world")