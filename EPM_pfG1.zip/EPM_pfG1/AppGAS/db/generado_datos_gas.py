import argparse
import random
import csv
from datetime import datetime, timedelta

# Pandas se usa para mostrar los datos de forma ordenada en la consola
# y para facilitar la exportación a CSV.
try:
    import pandas as pd
except ImportError:
    print("Error: La librería 'pandas' no está instalada.")
    print("Por favor, instálala con: pip install pandas")
    exit(1)

# --- CONFIGURACIÓN DE LOS DATOS SINTÉTICOS ---

# Lista de nombres de estaciones posibles
NOMBRES_ESTACIONES = [
    "Estacion_Recepcion_Norte",
    "Planta_Compresora_Central",
    "Punto_Distribucion_Sur",
    "Terminal_Almacenamiento_Oeste",
    "Valvula_Reguladora_Principal"
]

# Estados posibles de un equipo
ESTADOS_OPERATIVOS = ["NORMAL", "ALARMA", "MANTENIMIENTO"]

# Operadores de turno
OPERADORES = [f"Operador_{i}" for i in range(1, 6)]

# Rangos realistas para las variables de proceso
RANGOS = {
    "presion": {"min": 45.0, "max": 85.0, "unidad": "bar"},
    "temperatura": {"min": 5.0, "max": 35.0, "unidad": "°C"},
    "flujo": {"min": 100.0, "max": 5500.0, "unidad": "m³/h"},
    "poder_calorifico": {"min": 38.0, "max": 42.0, "unidad": "MJ/m³"},
    "densidad": {"min": 0.68, "max": 0.85, "unidad": "kg/m³"},
}

def generar_registro(timestamp: datetime, nombre_estacion: str, volumen_acumulado_anterior: float) -> dict:
    """
    Genera un diccionario con un registro de datos de una estación de gas.
    """
    # Generar un tag único para este punto de medición
    # Formato: ESTACION-PUNTO-MEDICION (ej: Planta_Compresora_Central-A-FLUJO)
    punto_medicion = random.choice(["A", "B", "C"])
    tipo_medicion = random.choice(["PRESION", "TEMPERATURA", "FLUJO"])
    tag = f"{nombre_estacion}-{punto_medicion}-{tipo_medicion}"

    # Generar valores numéricos dentro de los rangos definidos
    presion = round(random.uniform(RANGOS["presion"]["min"], RANGOS["presion"]["max"]), 2)
    temperatura = round(random.uniform(RANGOS["temperatura"]["min"], RANGOS["temperatura"]["max"]), 2)
    flujo = round(random.uniform(RANGOS["flujo"]["min"], RANGOS["flujo"]["max"]), 2)
    
    # El volumen acumulado es el anterior más el flujo en el intervalo de tiempo
    # Asumimos un intervalo de 10 minutos (1/6 de hora)
    volumen_acumulado = volumen_acumulado_anterior + (flujo / 6)
    
    poder_calorifico = round(random.uniform(RANGOS["poder_calorifico"]["min"], RANGOS["poder_calorifico"]["max"]), 4)
    densidad = round(random.uniform(RANGOS["densidad"]["min"], RANGOS["densidad"]["max"]), 3)

    return {
        "nombre_estacion": nombre_estacion,
        "tag": tag,
        "fecha": timestamp.isoformat(sep=' ', timespec='seconds'),
        "presion_bar": presion,
        "temperatura_c": temperatura,
        "flujo_m3_h": flujo,
        "volumen_acumulado_m3": round(volumen_acumulado, 2),
        "poder_calorifico_MJ_m3": poder_calorifico,
        "densidad_kg_m3": densidad,
        "estado_operativo": random.choices(ESTADOS_OPERATIVOS, weights=[85, 10, 5], k=1)[0], # Más probabilidad de estar normal
        "operador_responsable": random.choice(OPERADORES)
    }

def main():
    """
    Función principal que orquesta la generación de datos.
    """
    parser = argparse.ArgumentParser(
        description="Generador de datos sintéticos para la supervisión de una red de gas.",
        formatter_class=argparse.RawTextHelpFormatter
    )
    parser.add_argument(
        "n_registros",
        type=int,
        help="Número de registros a generar."
    )
    parser.add_argument(
        "--output", "-o",
        default="datos_supervision_gas.csv",
        help="Nombre del archivo CSV de salida (por defecto: datos_supervision_gas.csv)."
    )
    
    args = parser.parse_args()

    if args.n_registros <= 0:
        print("Error: El número de registros debe ser un entero positivo.")
        return

    print(f"Generando {args.n_registros} registros de datos de gas...")
    
    datos_generados = []
    timestamp_actual = datetime.now()
    volumen_inicial = random.uniform(100000, 500000) # Volumen inicial aleatorio

    # Generar los registros en un bucle
    for i in range(args.n_registros):
        # Cada registro será de una estación aleatoria
        estacion = random.choice(NOMBRES_ESTACIONES)
        
        registro = generar_registro(timestamp_actual, estacion, volumen_inicial)
        datos_generados.append(registro)
        
        # Actualizar el volumen acumulado para el siguiente ciclo
        volumen_inicial = registro['volumen_acumulado_m3']
        
        # Restar un intervalo de tiempo aleatorio (entre 5 y 15 minutos)
        timestamp_actual -= timedelta(minutes=random.randint(5, 15))

    # Ordenar los datos por fecha (del más antiguo al más reciente)
    datos_generados.reverse()

    # --- SALIDA A CONSOLA ---
    print("\n--- Vista Previa de los Datos Generados ---")
    df = pd.DataFrame(datos_generados)
    # Configurar pandas para mostrar todas las columnas y filas sin truncar
    pd.set_option('display.max_columns', None)
    pd.set_option('display.max_rows', None)
    pd.set_option('display.width', 200)
    print(df.to_string())
    
    # --- GUARDADO A ARCHIVO CSV ---
    try:
        with open(args.output, mode='w', newline='', encoding='utf-8') as archivo_csv:
            # Obtener los nombres de las columnas del primer registro
            fieldnames = datos_generados[0].keys()
            writer = csv.DictWriter(archivo_csv, fieldnames=fieldnames)
            
            writer.writeheader()
            writer.writerows(datos_generados)
            
        print(f"\n✅ Éxito! Se han guardado {len(datos_generados)} registros en el archivo '{args.output}'")
    except IOError as e:
        print(f"\n❌ Error al escribir en el archivo: {e}")

if __name__ == "__main__":
    main()