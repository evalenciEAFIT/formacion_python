#import AppGAS.app.prbSaludo as p
#from  AppGAS.app.prbSaludo import saludo1
from  AppGAS.app.prbSaludo import saludo2, saludo1
from    AppGAS.app.prbSaludo import *

#AppGAS.app.prbSaludo.saludo2()
saludo2()
#p.saludo1

