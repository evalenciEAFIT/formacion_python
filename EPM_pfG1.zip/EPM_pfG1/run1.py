from tabulate import tabulate
from AppGAS.db.cargarDatos import cargarCSV
import pandas as pd

global datos 
datos = pd.DataFrame()

def verDatos():
    global datos
    fuenteDatos = "datos1.csv"
    datos = cargarCSV(fuenteDatos)
    #print(tabulate(datos))
    #return datos

if __name__ == "__main__":
    verDatos()
    print(datos)